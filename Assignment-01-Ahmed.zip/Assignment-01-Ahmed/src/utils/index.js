export { startTiming, printElapsedTime } from './timeFunc.js';
export { wordFreq } from './wordFreq.js'